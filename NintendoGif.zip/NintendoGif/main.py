import imageio
from PIL import Image, ImageDraw, ImageFont
import numpy as np
import math
import os

# Initialization and User Input
TITLE = input("Enter the title text: ")
SUBTITLE = input("Enter the subtitle text: ")
print("Choose a theme: 1) Nintendo 2) Rainbow 3) Acid 4) Red on Black")
theme_choice = input("Your choice (1/2/3/4): ")

# Theme Configuration
BACKGROUND_COLOR = (255, 255, 255)  # Default to white for clarity in transition effects
if theme_choice == "1":
    # Nintendo Theme: Red on White, transitioning to solid red
    BACKGROUND_COLOR = (255, 0, 0)
    PALETTE = [(255, 255, 255), (255, 0, 0)]
elif theme_choice == "2":
    # Rainbow Theme: Full spectrum cycling
    BACKGROUND_COLOR = (255, 0, 0)
    PALETTE = [(255, 0, 0), (255, 165, 0), (255, 255, 0), (0, 255, 0), (0, 0, 255), (75, 0, 130), (238, 130, 238)]
elif theme_choice == "3":
    # Acid Theme: Bright, contrasting cycling
    BACKGROUND_COLOR = (255, 0, 0)
    PALETTE = [(255, 0, 255), (0, 255, 255), (255, 255, 0), (0, 0, 255), (255, 0, 0), (0, 255, 0), (255, 255, 255)]
elif theme_choice == "4":
    # Original Theme: Red text on black background
    BACKGROUND_COLOR = (0, 0, 0)  # Black background
    text_color = (255, 0, 0)  # Red text color
else:
    print("Invalid theme choice, defaulting to the Original theme.")
    BACKGROUND_COLOR = (255, 0, 0)
    PALETTE = [(255, 255, 255), (255, 0, 0)]

# Constants and Configuration
ANIMATION_LENGTH = 7  # Shorter animation for a faster transition
FRAME_RATE = 60
TOTAL_FRAMES = ANIMATION_LENGTH * FRAME_RATE
WIDTH, HEIGHT = 640, 480
FONT_PATH = "font//Gameboy.ttf"
FONT_SIZE = 60
SUB_FONT_SIZE = 30
PNG_PATH = "pics//nintendo.png"  # Update this to the path of your PNG file

# Load the PNG image (ensure it's not too large to fit on the frame with text)
png_image = Image.open(PNG_PATH).convert("RGBA")
fixed_size = (100, 100)  # For example, resize to 100x100 pixels

# Resize the image
png_image = png_image.resize(fixed_size)

# Load Font or Use Default
try:
    font = ImageFont.truetype(FONT_PATH, FONT_SIZE)
    sub_font = ImageFont.truetype(FONT_PATH, SUB_FONT_SIZE)
except OSError:
    print("Font load error, using default font.")
    font = ImageFont.load_default()
    sub_font = ImageFont.load_default()
def create_frame(frame_number, theme):
    img = Image.new('RGBA', (WIDTH, HEIGHT), BACKGROUND_COLOR)
    draw = ImageDraw.Draw(img)
    total_phase = (frame_number + 1) / TOTAL_FRAMES
    title_y = HEIGHT // 4  # For example, start the title a quarter way down the image
    subtitle_y = title_y + 90
    # Define text_color based on theme
    if theme == "2":  # Rainbow Theme
        PALETTE = [(255, 0, 0), (255, 165, 0), (255, 255, 0), (0, 255, 0), (0, 0, 255), (75, 0, 130), (238, 130, 238)]
        cycle_length = (TOTAL_FRAMES / len(PALETTE)) / 2
        color_index = int((frame_number / cycle_length) % len(PALETTE))
        text_color = PALETTE[color_index]
    elif theme == "3":  # Acid Theme
        PALETTE = [(255, 0, 255), (0, 255, 255), (255, 255, 0), (0, 0, 255), (255, 0, 0), (0, 255, 0), (255, 255, 255)]
        cycle_length = (TOTAL_FRAMES / len(PALETTE)) / 16
        color_index = int((frame_number / cycle_length) % len(PALETTE))
        text_color = PALETTE[color_index]
    elif theme == "1":  # Nintendo Theme
        text_color = (255, 255, 255)
    elif theme == "4":  # Original Theme: Red text on black background
        # Assuming BACKGROUND_COLOR is set to (0, 0, 0) elsewhere for this theme,
        # so only need to set text color here
        text_color = (255, 0, 0)  # Red
    else:  # Original theme and default case
        text_color = (0, 0, 0)  # Default to black

    # Drawing the title
    if total_phase <= 0.5:
        title_phase = total_phase / 0.5
        # Use ceil to ensure we always round up for character count
        title_chars = math.ceil(len(TITLE) * title_phase)
        # This condition ensures the full title is displayed in the last frame of its animation phase
        if frame_number >= (TOTAL_FRAMES // 2) - 1:
            title_chars = len(TITLE)
    else:
        title_chars = len(TITLE)
    draw.text((WIDTH // 2, HEIGHT // 3), TITLE[:title_chars], font=font, fill=text_color, anchor="mm")

    # Drawing the subtitle with corrected logic
    # Ensure subtitle appears clearly
    if total_phase > 0.5:
        subtitle_phase = (total_phase - 0.5) / 0.5
        subtitle_chars = math.ceil(len(SUBTITLE) * subtitle_phase)  # Calculate visible character count
    # Check if frame_number calculation might prevent subtitle from showing correctly
        if frame_number >= TOTAL_FRAMES - 1:
            subtitle_chars = len(SUBTITLE)
    # Make sure the subtitle position is correct and visible
        draw.text((WIDTH // 2, subtitle_y), SUBTITLE[:subtitle_chars], font=sub_font, fill=text_color, anchor="mm")

    
    if total_phase > 0.85:
        # Fixed PNG positioning
        # Position the PNG image a fixed distance below the subtitle_y
        image_y = subtitle_y + 40  # Fixed distance below where the subtitle is drawn
        image_x = (WIDTH - png_image.width) // 2  # Center the image horizontally
        
        # Paste the PNG image into the frame
        img.paste(png_image, (image_x, image_y), png_image if png_image.mode == 'RGBA' else None)

    return np.array(img)

frames = [create_frame(frame_number, theme_choice) for frame_number in range(TOTAL_FRAMES)]


frames = [create_frame(frame_number, theme_choice) for frame_number in range(TOTAL_FRAMES)]

# Save Animation
outputs_dir = "outputs"
if not os.path.exists(outputs_dir):
    os.makedirs(outputs_dir)

# Adjust the output_path to include the "outputs" directory
output_path = os.path.join(outputs_dir, f"{TITLE}.gif")

# Proceed to save the GIF
imageio.mimsave(output_path, frames, fps=FRAME_RATE)

# Confirm the save location to the user
print(f"GIF saved at {output_path}, themed as {['Nintendo', 'Rainbow', 'Acid', 'Original'][int(theme_choice)-1]}.")